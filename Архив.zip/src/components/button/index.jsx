import React from "react";
import styles from './styles.module.scss';
import clsx from "clsx";
import Loader from "../loader";

const Button = (props) => {
    const {
        children,
        className,
        onClick,
        type = 'button',
        disabled
    } = props

    const mainClasses = clsx (
        className,
        disabled ? styles['disabled-btn'] : styles.button
    )

    return (
        <div className={styles['button-wrap']}>
            <button
                disabled={disabled}
                onClick={onClick}
                type={type}
                className={mainClasses}
            >

                {children}
            </button>

        </div>

    )

}

export default Button