import React from "react";
import styles from './styles.module.scss';

const Loader = (props) => {
    return (
        <div className={styles['content']}>
            <div className={styles['spinner']}>
            </div>
        </div>
    )
}

export default Loader
